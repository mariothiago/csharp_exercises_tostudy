using System;

class HelloWorld {
  static void Main() {
    int a = 3;
    int b = 9;
    
    int produto = a * b;
    Console.WriteLine($"Produto = {produto}");
  }
}