using System;

class HelloWorld {
  static void Main() {
    double raio = 5;
    
    double n = 3.14159;
    double area = n * (raio * raio);
    
    Console.WriteLine($"Area = {area}");
  }
}