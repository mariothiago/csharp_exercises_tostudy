using System;

class HelloWorld {
  static void Main() {
    int a = 10;
    int b = 9;
    
    int soma = a + b;
    Console.WriteLine($"X = {soma}");
  }
}
